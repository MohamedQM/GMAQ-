# orrnob_drops_automation.py

import os

class base:
    @staticmethod
    def file_path(file_name):
        """Return the full path for the given file name."""
        return os.path.join(os.getcwd(), file_name)

    @staticmethod
    def create_line(length=50):
        """Create a line of specified length."""
        return "=" * length

    @staticmethod
    def clear_terminal():
        """Clear the terminal screen."""
        os.system('clear' if os.name == 'posix' else 'cls')

    @staticmethod
    def log(message):
        """Log messages to the console."""
        print(message)